import streamlit as st
import PyPDF2
import io
import os
import json
import re
from dotenv import load_dotenv
from google import genai

load_dotenv()

# ── Page Config ──────────────────────────────────────────────
st.set_page_config(page_title="Resume ATS Scorer", page_icon="📄", layout="wide")

# ── Gemini Client ────────────────────────────────────────────
def get_gemini_client():
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key or api_key == "your_gemini_api_key_here":
        return None
    return genai.Client(api_key=api_key)


# ── PDF Text Extraction ─────────────────────────────────────
def extract_text_from_pdf(uploaded_file) -> str:
    reader = PyPDF2.PdfReader(io.BytesIO(uploaded_file.read()))
    text = ""
    for page in reader.pages:
        page_text = page.extract_text()
        if page_text:
            text += page_text + "\n"
    return text.strip()


# ── Gemini Analysis ─────────────────────────────────────────
ANALYSIS_PROMPT = """
You are an expert ATS (Applicant Tracking System) scanner and career advisor.

Analyze the following resume against the provided job description and return a JSON response with EXACTLY this structure (no markdown, no code fences, just raw JSON):

{{
  "ats_score": <number 0-100>,
  "summary": "<2-3 sentence overall assessment>",
  "matched_keywords": ["keyword1", "keyword2"],
  "missing_keywords": ["keyword1", "keyword2"],
  "strengths": ["strength1", "strength2"],
  "weaknesses": ["weakness1", "weakness2"],
  "suggestions": ["suggestion1", "suggestion2"],
  "experience_match": "<how well the experience matches the role>",
  "skills_match": "<how well the skills match>",
  "education_match": "<how well the education matches>"
}}

RULES:
- Be honest and specific in your analysis.
- The ATS score should reflect how likely this resume would pass an ATS for this specific job.
- Focus on real keyword matches, not vague generalizations.
- Provide actionable suggestions.

───────────────────────────
RESUME:
{resume_text}

───────────────────────────
JOB DESCRIPTION:
{job_description}
"""


def analyze_resume(client, resume_text: str, job_description: str) -> dict:
    prompt = ANALYSIS_PROMPT.format(
        resume_text=resume_text, job_description=job_description
    )
    response = client.models.generate_content(
        model="gemini-2.0-flash",
        contents=prompt,
    )
    raw = response.text.strip()
    # Strip markdown code fences if present
    raw = re.sub(r"^```(?:json)?\s*", "", raw)
    raw = re.sub(r"\s*```$", "", raw)
    return json.loads(raw)


# ── UI Helpers ───────────────────────────────────────────────
def score_color(score: int) -> str:
    if score >= 80:
        return "🟢"
    if score >= 60:
        return "🟡"
    return "🔴"


def render_results(data: dict):
    score = data["ats_score"]
    st.markdown("---")
    st.markdown(f"## {score_color(score)} ATS Score: **{score}/100**")
    st.markdown(f"**Summary:** {data['summary']}")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("### ✅ Matched Keywords")
        if data["matched_keywords"]:
            for kw in data["matched_keywords"]:
                st.markdown(f"- `{kw}`")
        else:
            st.info("No keyword matches found.")

        st.markdown("### 💪 Strengths")
        for s in data["strengths"]:
            st.success(s)

    with col2:
        st.markdown("### ❌ Missing Keywords")
        if data["missing_keywords"]:
            for kw in data["missing_keywords"]:
                st.markdown(f"- `{kw}`")
        else:
            st.info("No missing keywords — great!")

        st.markdown("### ⚠️ Weaknesses")
        for w in data["weaknesses"]:
            st.warning(w)

    st.markdown("---")
    st.markdown("### 🎯 Detailed Match")
    det1, det2, det3 = st.columns(3)
    det1.metric("Experience", data.get("experience_match", "N/A"))
    det2.metric("Skills", data.get("skills_match", "N/A"))
    det3.metric("Education", data.get("education_match", "N/A"))

    st.markdown("### 📝 Suggestions to Improve")
    for i, suggestion in enumerate(data["suggestions"], 1):
        st.info(f"**{i}.** {suggestion}")


# ── Main App ─────────────────────────────────────────────────
def main():
    st.title("📄 Resume ATS Scorer")
    st.markdown(
        "Upload your resume and paste the job description to see how well you match!"
    )

    client = get_gemini_client()

    # Sidebar for API key if not set
    with st.sidebar:
        st.header("⚙️ Settings")
        if client is None:
            st.warning("Gemini API key not found in `.env` file.")
            api_key_input = st.text_input(
                "Enter your Gemini API Key",
                type="password",
                help="Get your free key at https://aistudio.google.com/apikey",
            )
            if api_key_input:
                client = genai.Client(api_key=api_key_input)
                st.success("API key set!")
        else:
            st.success("Gemini API key loaded from .env")

        st.markdown("---")
        st.markdown(
            "**How to get a free API key:**\n"
            "1. Go to [Google AI Studio](https://aistudio.google.com/apikey)\n"
            "2. Click **Create API Key**\n"
            "3. Copy and paste it above or in your `.env` file"
        )

    # Main content
    col_left, col_right = st.columns(2)

    with col_left:
        st.subheader("📎 Upload Resume (PDF)")
        uploaded_file = st.file_uploader(
            "Choose a PDF file", type=["pdf"], label_visibility="collapsed"
        )
        if uploaded_file:
            resume_text = extract_text_from_pdf(uploaded_file)
            if resume_text:
                st.success(f"Extracted {len(resume_text)} characters from resume.")
                with st.expander("Preview extracted text"):
                    st.text(resume_text[:2000] + ("..." if len(resume_text) > 2000 else ""))
            else:
                st.error("Could not extract text from PDF. Try a different file.")
                resume_text = None
        else:
            resume_text = None

    with col_right:
        st.subheader("📋 Job Description")
        job_description = st.text_area(
            "Paste the job description here",
            height=300,
            placeholder="Paste the full job description here...",
            label_visibility="collapsed",
        )

    st.markdown("---")

    # Analyze button
    if st.button("🔍 Analyze Resume", type="primary", use_container_width=True):
        if client is None:
            st.error("Please set your Gemini API key in the sidebar.")
        elif resume_text is None:
            st.error("Please upload a resume PDF.")
        elif not job_description.strip():
            st.error("Please paste a job description.")
        else:
            with st.spinner("Analyzing your resume with AI... This may take a few seconds."):
                try:
                    result = analyze_resume(client, resume_text, job_description)
                    render_results(result)
                except json.JSONDecodeError:
                    st.error("Failed to parse AI response. Please try again.")
                except Exception as e:
                    st.error(f"An error occurred: {e}")


if __name__ == "__main__":
    main()
